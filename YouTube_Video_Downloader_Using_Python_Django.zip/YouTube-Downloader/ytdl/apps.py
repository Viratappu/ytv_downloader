from django.apps import AppConfig


class YtdlConfig(AppConfig):
    name = 'ytdl'
